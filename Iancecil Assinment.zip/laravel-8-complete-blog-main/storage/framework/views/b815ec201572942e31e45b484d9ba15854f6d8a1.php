<?php echo e($slot); ?>

<?php /**PATH C:\Users\LENOVO\OneDrive\Documents\WEB DEV\laravel-8-complete-blog-main\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>